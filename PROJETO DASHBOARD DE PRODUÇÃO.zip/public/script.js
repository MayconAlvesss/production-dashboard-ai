import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getFirestore, doc, setDoc, onSnapshot } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";

const GEMINI_KEY = ""; 
const firebaseConfig = {
    apiKey: "AIzaSyD26o_heKopixxpHrcT6yGR1PaY4TVpI1U",
    authDomain: "dashboard-producao-empresa.firebaseapp.com",
    projectId: "dashboard-producao-empresa",
    storageBucket: "dashboard-producao-empresa.firebasestorage.app",
    messagingSenderId: "246718812896",
    appId: "1:246718812896:web:3b31a9ce2bc3ccb78e3685"
};

const fb = initializeApp(firebaseConfig);
const db = getFirestore(fb);
const auth = getAuth(fb);
const dbPath = doc(db, 'dashboards', 'sharedDashboardData');

const state = {
    data: {}, 
    serviceTypes: ["Hélice Contínua", "Estaca Pré-moldada", "Concretagem", "Sondagem"],
    machineTypes: ["Equipamento 01", "Equipamento 02"],
    serviceColors: {},
    charts: {},
    months: ['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'],
    colorMap: { "Perfuratriz": "#3b82f6", "Bate-Estaca": "#10b981", "Bomba de Concreto": "#a855f7" },
    defaultPalette: ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444', '#ec4899'],
    // VARIAVEIS AUXILIARES MODAL
    tempPrompt: null,
    tempConfirm: null
};

const getWeekOfMonth = (dateStr) => {
    if(!dateStr) return 1;
    const d = new Date(dateStr);
    const date = d.getUTCDate();
    return Math.ceil(date / 7);
};

async function callGemini(prompt, isJson = false) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${GEMINI_KEY}`;
    const payload = { contents: [{ parts: [{ text: prompt }] }] };
    if (isJson) payload.generationConfig = { responseMimeType: "application/json" };
    
    try {
        const response = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        if (!response.ok) throw new Error("API Error");
        const data = await response.json();
        return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    } catch (error) {
        console.error("Gemini Error:", error);
        throw error;
    }
}

window.app = {
    aiTimeout: null,
    navigate: (view, btn) => {
        document.querySelectorAll('section').forEach(s => s.classList.add('hidden'));
        document.getElementById(`view-${view}`).classList.remove('hidden');
        document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        if(view === 'settings') app.renderSettings();
        if(view === 'overview') app.updateDashboard();
    },

    openModal: (id) => {
        const m = document.getElementById(id);
        if(!m) return;
        m.classList.remove('hidden');
        if(id === 'modal-entry' && !document.getElementById('in-id').value) {
            document.getElementById('in-id').value = ""; document.getElementById('in-client').value = ""; document.getElementById('in-value').value = "";
            const now = new Date(); document.getElementById('in-date').value = now.toISOString().substring(0, 10);
            app.populateSelects(); document.getElementById('in-dias-parados').value = "0"; app.updateWeekLabel();
        }
    },
    closeModal: (id) => { document.getElementById(id).classList.add('hidden'); if(id==='modal-entry') document.getElementById('in-id').value=""; },

    openAIChat: () => app.openModal('modal-ai-chat'),

    sendChatMessage: async () => {
        const input = document.getElementById('chat-input');
        const text = input.value.trim();
        if(!text) return;

        const history = document.getElementById('chat-history');
        const typing = document.getElementById('ai-typing');
        
        history.innerHTML += `<div class="chat-bubble chat-user">${text}</div>`;
        input.value = "";
        history.scrollTop = history.scrollHeight;
        typing.classList.remove('hidden');

        const contextData = {
            machines: state.machineTypes,
            services: state.serviceTypes,
            summary: Object.values(state.data).flat().slice(0, 20) 
        };

        const prompt = `
            Você é um assistente de Dashboard. Contexto: ${JSON.stringify(contextData)}
            Usuário: "${text}". Objetivo: JSON.
            1. 'insert_data': maquina, cliente, servico, valor, data.
            2. 'insert_batch': payload=[{maquina...}].
            3. 'add_setting': target, value.
            4. 'query': message.
        `;

        try {
            const result = await callGemini(prompt, true);
            typing.classList.add('hidden');
            let jsonStr = result.replace(/```json/g, "").replace(/```/g, "");
            const aiResponse = JSON.parse(jsonStr);
            
            let aiHtml = `<div class="chat-bubble chat-ai ai-content">${marked.parse(aiResponse.message || "")}</div>`;

            if(aiResponse.intent === 'insert_data') {
                const p = aiResponse.payload || {};
                aiHtml += `<div class="chat-bubble chat-ai bg-gray-800 border border-gray-600 p-3"><ul class="text-xs space-y-1 mb-2"><li><b>Máq:</b> ${p.maquina||'?'}</li><li><b>Valor:</b> R$ ${p.valor}</li></ul><button onclick='app.confirmAIInsert(${JSON.stringify(p)})' class="w-full bg-green-600 text-white text-xs font-bold py-2 rounded">Confirmar</button></div>`;
            } else if (aiResponse.intent === 'insert_batch') {
                 aiHtml += `<div class="chat-bubble chat-ai bg-gray-800 border border-gray-600 p-3"><p class="text-xs mb-2 text-white">Lote: <b>${aiResponse.payload.length}</b> itens.</p><button onclick='app.confirmAIBatchInsert(${JSON.stringify(aiResponse.payload)})' class="w-full bg-indigo-600 text-white text-xs font-bold py-2 rounded">Importar</button></div>`;
            } else if(aiResponse.intent === 'add_setting') {
                const p = aiResponse.payload || {};
                aiHtml += `<div class="chat-bubble chat-ai bg-gray-800 border border-gray-600 p-3"><p class="text-xs mb-2">Adicionar <b>"${p.value}"</b>?</p><button onclick='app.confirmAISetting("${p.target}", "${p.value}")' class="w-full bg-blue-600 text-white text-xs font-bold py-2 rounded">Confirmar</button></div>`;
            }

            history.innerHTML += aiHtml;
            history.scrollTop = history.scrollHeight;
        } catch(e) {
            typing.classList.add('hidden');
            history.innerHTML += `<div class="chat-bubble chat-ai text-red-400">Erro na IA.</div>`;
        }
    },

    confirmAIInsert: async (data) => {
        const now = new Date();
        const mKey = state.months[now.getMonth()];
        const entry = { id: "IA_" + Date.now(), date: data.data || now.toISOString(), maquina: data.maquina || "Desconhecida", tipo: "Perfuratriz", cliente: data.cliente || "Avulso", servico: data.servico || "Geral", faturamento: parseFloat(data.valor) || 0, status: 'operando', diasParados: 0 };
        if(!state.data[mKey]) state.data[mKey] = [];
        state.data[mKey].push(entry);
        await setDoc(dbPath, { fullRawData: state.data }, { merge: true });
        app.updateDashboard();
        document.getElementById('chat-history').innerHTML += `<div class="chat-bubble chat-ai text-green-400">Salvo!</div>`;
    },
    confirmAIBatchInsert: async (items) => {
        let count = 0;
        for (const item of items) {
            let tipo = "Perfuratriz";
            const mUpper = (item.maquina || "").toUpperCase();
            if(mUpper.includes("BATE") || mUpper.includes("JUNTTAN")) tipo = "Bate-Estaca";
            if(mUpper.includes("BOMBA") || mUpper.includes("HBT")) tipo = "Bomba de Concreto";
            const dateObj = new Date(item.data); if (isNaN(dateObj.getTime())) continue;
            const mKey = state.months[dateObj.getMonth()];
            const entry = { id: "IA_" + Date.now() + Math.random(), date: item.data, maquina: item.maquina || "Desconhecida", tipo, cliente: item.cliente || "Avulso", servico: item.servico || "Geral", faturamento: parseFloat(item.valor) || 0, status: 'operando', diasParados: 0 };
            if(!state.data[mKey]) state.data[mKey] = []; state.data[mKey].push(entry); count++;
        }
        await setDoc(dbPath, { fullRawData: state.data }, { merge: true });
        app.updateDashboard();
        document.getElementById('chat-history').innerHTML += `<div class="chat-bubble chat-ai text-green-400">Importados: ${count}!</div>`;
    },
    confirmAISetting: async (target, value) => { state[target].push(value); await setDoc(dbPath, {[target]: state[target]}, {merge:true}); app.renderSettings(); },
    
    populateSelects: () => {
        document.getElementById('in-machine').innerHTML = state.machineTypes.map(m => `<option value="${m}">${m}</option>`).join('');
        document.getElementById('in-service').innerHTML = state.serviceTypes.map(s => `<option value="${s}">${s}</option>`).join('');
    },
    updateWeekLabel: () => {
        const val = document.getElementById('in-date').value;
        if(val) { const w = getWeekOfMonth(val); document.getElementById('in-week-display').textContent = `S${w}`; }
    },
    toggleDateInputs: () => {
        const mode = document.getElementById('view-granularity').value;
        if(mode === 'week') { document.getElementById('container-date-range').classList.add('hidden'); document.getElementById('container-date-single').classList.remove('hidden'); } else { document.getElementById('container-date-range').classList.remove('hidden'); document.getElementById('container-date-single').classList.add('hidden'); }
        app.updateDashboard();
    },
    
    saveEntry: async () => {
        try {
            const existingId = document.getElementById('in-id').value;
            const dateVal = document.getElementById('in-date').value;
            if(!dateVal) return alert("Selecione uma data!");
            
            // Garante que o usuário está autenticado antes de salvar
            if (!auth.currentUser) {
                await signInAnonymously(auth);
            }

            const dateObj = new Date(dateVal + 'T12:00:00');
            const mKey = state.months[dateObj.getMonth()];
            const entry = { 
                id: existingId || "ID_" + Date.now(), 
                date: dateObj.toISOString(), 
                maquina: document.getElementById('in-machine').value, 
                tipo: document.getElementById('in-tipo-cat').value, 
                cliente: document.getElementById('in-client').value || 'Avulso', 
                servico: document.getElementById('in-service').value, 
                faturamento: parseFloat(document.getElementById('in-value').value) || 0, 
                status: document.getElementById('in-status').value, 
                diasParados: parseInt(document.getElementById('in-dias-parados').value) || 0 
            };
            
            Object.keys(state.data).forEach(month => { if (Array.isArray(state.data[month])) { state.data[month] = state.data[month].filter(d => d.id !== entry.id); } });
            if(!state.data[mKey]) state.data[mKey] = [];
            state.data[mKey].push(entry);
            
            await setDoc(dbPath, { fullRawData: state.data }, { merge: true });
            
            const feedback = document.getElementById('save-feedback'); feedback.style.opacity = '1'; setTimeout(() => { feedback.style.opacity = '0'; }, 2000);
            if(existingId) app.closeModal('modal-entry'); 
            app.updateDashboard();
            
            const modalList = document.getElementById('modal-drill-list');
            if(!modalList.classList.contains('hidden')) {
                 app.closeModal('modal-drill-list'); 
            }
        } catch (error) {
            console.error("Erro ao salvar:", error);
            alert("Erro ao salvar dados. Verifique sua conexão. " + error.message);
        }
    },
    
    updateDashboard: () => {
        const search = document.getElementById('global-search').value.toLowerCase();
        const typeFilter = document.getElementById('filter-type').value;
        const granularity = document.getElementById('view-granularity').value;
        const weekFilter = document.getElementById('filter-week-num').value;
        let sDate, eDate;
        if (granularity === 'week') { const singleDate = document.getElementById('date-single').value; sDate = singleDate; eDate = singleDate; eDate = singleDate; } else { sDate = document.getElementById('date-start').value; eDate = document.getElementById('date-end').value; }
        let filtered = [];
        Object.values(state.data).forEach(mArr => {
            if(Array.isArray(mArr)) mArr.forEach(d => {
                const dM = d.date.substring(0, 7);
                if(dM >= sDate && dM <= eDate) {
                    let matchesWeek = true;
                    if (granularity === 'week' && weekFilter !== 'all') { if (getWeekOfMonth(d.date).toString() !== weekFilter) { matchesWeek = false; } }
                    if(matchesWeek) { if((!search || d.maquina.toLowerCase().includes(search) || d.cliente.toLowerCase().includes(search)) && (typeFilter === 'all' || d.tipo === typeFilter)) { filtered.push(d); } }
                }
            });
        });
        
        const total = filtered.reduce((acc, i) => acc + i.faturamento, 0);
        const perf = filtered.filter(i => i.tipo === 'Perfuratriz').reduce((acc, i) => acc + i.faturamento, 0);
        const bate = filtered.filter(i => i.tipo === 'Bate-Estaca').reduce((acc, i) => acc + i.faturamento, 0);
        const bomba = filtered.filter(i => i.tipo === 'Bomba de Concreto').reduce((acc, i) => acc + i.faturamento, 0);
        document.getElementById('kpi-total').textContent = total.toLocaleString('pt-BR', {style:'currency', currency:'BRL', maximumFractionDigits:0});
        document.getElementById('kpi-perf').textContent = perf.toLocaleString('pt-BR', {style:'currency', currency:'BRL', maximumFractionDigits:0});
        document.getElementById('kpi-bate').textContent = bate.toLocaleString('pt-BR', {style:'currency', currency:'BRL', maximumFractionDigits:0});
        document.getElementById('kpi-bomba').textContent = bomba.toLocaleString('pt-BR', {style:'currency', currency:'BRL', maximumFractionDigits:0});
        
        app.renderCharts(filtered);
        
        // Debounce AI Analysis
        if(app.aiTimeout) clearTimeout(app.aiTimeout);
        app.aiTimeout = setTimeout(() => {
            app.openAIAnalysis(filtered);
        }, 1000);
    },
    
    editEntry: (id) => {
        let found = null;
        Object.values(state.data).forEach(m => { const d = m.find(i => i.id === id); if(d) found = d; });
        if(!found) return;
        document.getElementById('in-id').value = found.id; document.getElementById('in-client').value = found.cliente; document.getElementById('in-value').value = found.faturamento; document.getElementById('in-date').value = found.date.substring(0, 10); document.getElementById('in-tipo-cat').value = found.tipo; app.populateSelects(); document.getElementById('in-machine').value = found.maquina; document.getElementById('in-service').value = found.servico; document.getElementById('in-status').value = found.status; document.getElementById('in-dias-parados').value = found.diasParados || 0; app.updateWeekLabel(); 
        app.closeModal('modal-drill-list');
        app.openModal('modal-entry');
    },
    deleteEntry: (id) => { 
        state.tempConfirm = { type: 'entry', id: id };
        document.getElementById('modal-confirm').classList.remove('hidden');
    },
    
    // --- GRÁFICOS & INTERATIVIDADE ---
    renderCharts: (data) => {
        const machineAgg = data.reduce((acc, i) => { if(!acc[i.maquina]) acc[i.maquina] = { val: 0, tipo: i.tipo }; acc[i.maquina].val += i.faturamento; return acc; }, {});
        const mLabels = Object.keys(machineAgg).sort((a,b) => machineAgg[b].val - machineAgg[a].val);
        app.drawChart('chart-production', 'bar', mLabels, mLabels.map(l => machineAgg[l].val), mLabels.map(l => state.colorMap[machineAgg[l].tipo]));
        
        const sAgg = data.reduce((acc, i) => { acc[i.servico] = (acc[i.servico]||0)+i.faturamento; return acc; }, {});
        const sLabels = Object.keys(sAgg);
        const sColors = sLabels.map((s, idx) => state.serviceColors[s] || state.defaultPalette[idx % state.defaultPalette.length]);
        app.drawChart('chart-service', 'doughnut', sLabels, Object.values(sAgg), sColors);
        
        const clientAgg = data.reduce((acc, i) => { acc[i.cliente] = (acc[i.cliente]||0)+i.faturamento; return acc; }, {});
        const cLabels = Object.keys(clientAgg).sort((a,b) => clientAgg[b] - clientAgg[a]).slice(0, 10);
        app.drawChart('chart-clients', 'bar', cLabels, cLabels.map(l => clientAgg[l]), '#10b981', true);
        
        const granularity = document.getElementById('view-granularity').value;
        const weekFilter = document.getElementById('filter-week-num').value;
        const trend = data.reduce((acc, i) => { let key; if (granularity === 'week') { if (weekFilter === 'all') { const weekNum = getWeekOfMonth(i.date); key = `S${weekNum}`; } else { const dObj = new Date(i.date); key = `${dObj.getUTCDate()}/${dObj.getUTCMonth() + 1}`; } } else { key = i.date.substring(0, 7); } acc[key] = (acc[key]||0)+i.faturamento; return acc; }, {});
        const sortedKeys = Object.keys(trend).sort();
        app.drawChart('chart-trend', 'line', sortedKeys, sortedKeys.map(l => trend[l]), '#3b82f6');
        
        // CORREÇÃO: Gráfico de Rentabilidade agora usa as cores dos serviços
        const servRent = data.reduce((acc, i) => { if(!acc[i.servico]) acc[i.servico] = { sum: 0, count: 0 }; acc[i.servico].sum += i.faturamento; acc[i.servico].count++; return acc; }, {});
        const rLabels = Object.keys(servRent);
        // Mapeia cada label para a cor configurada no state.serviceColors
        const rColors = rLabels.map(s => state.serviceColors[s] || state.defaultPalette[0]); 
        app.drawChart('chart-profitability', 'bar', rLabels, rLabels.map(l => servRent[l].sum / servRent[l].count), rColors);
        
        const idleAgg = data.reduce((acc, i) => { if(i.diasParados > 0) { acc[i.maquina] = (acc[i.maquina]||0) + i.diasParados; } return acc; }, {});
        const iLabels = Object.keys(idleAgg).sort((a,b) => idleAgg[b] - idleAgg[a]); 
        app.drawChart('chart-idle', 'bar', iLabels, iLabels.map(l => idleAgg[l]), '#ef4444');
    },
    
    drawChart: (id, type, labels, values, colors, horizontal = false) => {
        const canvas = document.getElementById(id); if(!canvas) return;
        const ctx = canvas.getContext('2d');
        if(state.charts[id]) state.charts[id].destroy();
        Chart.defaults.color = '#6b7280'; Chart.defaults.borderColor = '#1f2937';
        let datasetConfig = { 
            data: values, 
            backgroundColor: colors, 
            borderRadius: 4, 
            fill: type === 'line', 
            tension: 0.4
        };
        
        const options = { 
            indexAxis: horizontal ? 'y' : 'x', 
            responsive: true, 
            maintainAspectRatio: false, 
            plugins: { 
                legend: { display: type === 'doughnut', labels: { boxWidth: 10, font: { size: 10 } } },
                datalabels: { display: false }
            }, 
            scales: {},
            onClick: (e, elements, chart) => {
                if (elements[0]) {
                    const i = elements[0].index;
                    const label = chart.data.labels[i];
                    app.handleChartClick(id, label);
                }
            }
        };

        if (type === 'line') { 
            const gradient = ctx.createLinearGradient(0, 0, 0, 300); 
            gradient.addColorStop(0, 'rgba(59, 130, 246, 0.2)'); gradient.addColorStop(1, 'rgba(59, 130, 246, 0)'); 
            datasetConfig.backgroundColor = gradient; datasetConfig.borderColor = '#3b82f6'; 
            datasetConfig.pointRadius = 4; datasetConfig.pointBackgroundColor = '#1f2937'; datasetConfig.pointBorderColor = '#3b82f6'; datasetConfig.pointBorderWidth = 2; datasetConfig.pointHoverRadius = 6;
        }
        
        if (type === 'doughnut') {
            datasetConfig.borderWidth = 0; datasetConfig.hoverOffset = 10;
            options.plugins.tooltip = { enabled: true, callbacks: { label: function(context) { let label = context.label || ''; if (label) { label += ': '; } let value = context.parsed; let total = context.chart._metasets[context.datasetIndex].total; let percentage = (value * 100 / total).toFixed(1) + "%"; return label + value.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'}) + " (" + percentage + ")"; } } };
        } else {
            options.scales = { y: { grid: { color: '#1f2937' }, ticks: { font: { size: 9 } } }, x: { grid: { display: false }, ticks: { font: { size: 9 }, autoSkip: false, maxRotation: 45, minRotation: 0 } } };
        }

        state.charts[id] = new Chart(canvas, { type: type, data: { labels, datasets: [datasetConfig] }, options: options });
    },

    handleChartClick: (chartId, label) => {
        let filterFn = null;
        let title = label;

        if (chartId === 'chart-production') {
            filterFn = (d) => d.maquina === label;
            title = `Máquina: ${label}`;
        } else if (chartId === 'chart-service') {
            filterFn = (d) => d.servico === label;
            title = `Serviço: ${label}`;
        } else if (chartId === 'chart-trend') {
            title = `Período: ${label}`;
            const granularity = document.getElementById('view-granularity').value;
            if(granularity === 'week') {
                 if(label.startsWith('S')) {
                     const w = label.replace('S', '');
                     filterFn = (d) => getWeekOfMonth(d.date).toString() === w;
                 } else {
                     filterFn = (d) => {
                         const dObj = new Date(d.date);
                         const k = `${dObj.getUTCDate()}/${dObj.getUTCMonth() + 1}`;
                         return k === label;
                     };
                 }
            } else {
                filterFn = (d) => d.date.substring(0, 7) === label;
            }
        } else if (chartId === 'chart-clients') {
            filterFn = (d) => d.cliente === label;
            title = `Cliente: ${label}`;
        } else {
            return; 
        }

        app.openDrillModal(title, filterFn);
    },

    openDrillModal: (title, filterFn) => {
        let allData = [];
        Object.values(state.data).forEach(arr => allData.push(...arr));
        const clickedData = allData.filter(filterFn);
        clickedData.sort((a,b) => new Date(b.date) - new Date(a.date));

        document.getElementById('drill-list-title').textContent = title;
        const tbody = document.getElementById('drill-list-body');
        
        if (clickedData.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="p-4 text-center text-gray-500">Nenhum registro encontrado.</td></tr>';
        } else {
            tbody.innerHTML = clickedData.map(d => `
                <tr class="border-b border-gray-800 hover:bg-gray-800/50 transition">
                    <td class="p-3 text-gray-400 font-mono text-[10px]">${new Date(d.date).toLocaleDateString()}</td>
                    <td class="p-3 text-white font-bold text-xs">${d.maquina}</td>
                    <td class="p-3 text-white text-xs">${d.cliente}</td>
                    <td class="p-3 text-right text-emerald-400 font-mono text-xs">R$ ${d.faturamento.toLocaleString()}</td>
                    <td class="p-3 text-center flex justify-center gap-2">
                        <button onclick="app.editEntry('${d.id}')" class="w-7 h-7 rounded bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white flex items-center justify-center transition" title="Editar">
                            <i class="ph-bold ph-pencil-simple"></i>
                        </button>
                        <button onclick="app.deleteEntry('${d.id}')" class="w-7 h-7 rounded bg-red-600/20 text-red-400 hover:bg-red-600 hover:text-white flex items-center justify-center transition" title="Excluir">
                            <i class="ph-bold ph-trash"></i>
                        </button>
                    </td>
                </tr>
            `).join('');
        }
        
        app.openModal('modal-drill-list');
    },

    // --- FIM INTERATIVIDADE ---

    expandChart: (type) => { app.openModal('modal-expand'); const key = type === 'production' ? 'maquina' : 'servico'; let filtered = Object.values(state.data).flat(); const agg = filtered.reduce((acc, i) => { if(!acc[i[key]]) acc[i[key]] = { val: 0, tipo: i.tipo }; acc[i[key]].val += i.faturamento; return acc; }, {}); const labels = Object.keys(agg).sort((a,b) => agg[b].val - agg[a].val); document.getElementById('expand-table-body').innerHTML = labels.map((k, i) => `<tr class="cursor-pointer hover:bg-gray-800" onclick="app.showDrill('${k}', '${key}')"><td class="p-3 border-b border-gray-800 text-white font-bold text-xs flex justify-between"><span>${i+1}. ${k}</span> <i class="ph-bold ph-caret-right text-gray-600"></i></td><td class="p-3 border-b border-gray-800 text-right text-blue-400 font-mono text-xs">R$ ${agg[k].val.toLocaleString()}</td></tr>`).join(''); app.drawChart('chart-expanded', 'bar', labels, labels.map(l => agg[l].val), labels.map(l => type === 'production' ? state.colorMap[agg[l].tipo] : '#3b82f6')); },
    showDrill: (val, key) => { 
        document.getElementById('drill-down-container').classList.remove('hidden'); 
        document.getElementById('drill-title').textContent = val; 
        let filtered = Object.values(state.data).flat().filter(d => d[key] === val); 
        document.getElementById('drill-table-body').innerHTML = filtered.sort((a,b)=>new Date(b.date)-new Date(a.date)).map(d => `
            <tr class="border-b border-gray-800 hover:bg-gray-800/50">
                <td class="p-3 text-gray-400 font-mono text-[10px]">${new Date(d.date).toLocaleDateString()}</td>
                <td class="p-3 text-white font-bold text-xs">${d.cliente}</td>
                <td class="p-3 text-right text-emerald-400 font-mono text-xs">R$ ${d.faturamento.toLocaleString()}</td>
                <td class="p-3 text-center flex justify-center gap-2">
                     <button onclick="app.editEntry('${d.id}')" class="text-blue-500 hover:text-white transition"><i class="ph-bold ph-pencil-simple"></i></button>
                     <button onclick="app.deleteEntry('${d.id}')" class="text-gray-500 hover:text-red-500 transition"><i class="ph-bold ph-trash"></i></button>
                </td>
            </tr>`).join(''); 
    },
    closeDrillDown: () => document.getElementById('drill-down-container').classList.add('hidden'),
    
    openAIAnalysis: async (data) => {
        const elTextReview = document.getElementById('ai-text-review');
        if(!data.length) { elTextReview.innerHTML = "Sem dados suficientes."; return; }
        const total = data.reduce((acc, i) => acc + i.faturamento, 0); const avg = total / data.length; 
        elTextReview.innerHTML = `<span class="flex items-center gap-2 ai-thinking"><i class="ph ph-spinner animate-spin"></i> Gemini está analisando...</span>`;
        
        // Widgets Cálculos
        const today = new Date();
        let growthVal = "--", growthDesc = "Aguardando mais dados";
        if (data.length > 5) {
            const mid = Math.floor(data.length / 2);
            const oldPart = data.slice(0, mid).reduce((a,b)=>a+b.faturamento,0) / mid;
            const newPart = data.slice(mid).reduce((a,b)=>a+b.faturamento,0) / (data.length - mid);
            const diff = newPart - oldPart;
            const pct = oldPart > 0 ? (diff / oldPart) * 100 : 0;
            growthVal = (pct > 0 ? "+" : "") + pct.toFixed(1) + "%";
            growthDesc = pct > 0 ? "Crescimento recente" : "Desaceleração";
            document.getElementById('ai-widget-growth-val').textContent = growthVal;
            document.getElementById('ai-widget-growth-desc').textContent = growthDesc;
            document.getElementById('ai-widget-growth-val').className = pct >= 0 ? "text-2xl font-bold text-emerald-400 mb-1" : "text-2xl font-bold text-red-400 mb-1";
        }
        
        const dailySum = data.reduce((acc, curr) => { const date = curr.date.substring(0, 10); acc[date] = (acc[date] || 0) + curr.faturamento; return acc; }, {});
        let bestDay = { date: '-', val: 0 };
        for (const [date, val] of Object.entries(dailySum)) { if (val > bestDay.val) bestDay = { date, val }; }
        if (bestDay.val > 0) {
            const bdParts = bestDay.date.split('-');
            document.getElementById('ai-widget-peak-val').textContent = `Dia ${bdParts[2]}`;
            document.getElementById('ai-widget-peak-desc').textContent = `R$ ${bestDay.val.toLocaleString('pt-BR',{maximumFractionDigits:0})}`;
        }

        const projection = total > 0 ? total * 1.15 : 0;
        document.getElementById('ai-widget-forecast-val').textContent = projection.toLocaleString('pt-BR',{style:'currency',currency:'BRL', maximumFractionDigits:0});

        const clientSum = data.reduce((acc, curr) => { acc[curr.cliente] = (acc[curr.cliente] || 0) + curr.faturamento; return acc; }, {});
        const topClients = Object.entries(clientSum).sort(([,a], [,b]) => b - a).slice(0, 3);
        document.getElementById('ai-top-list').innerHTML = topClients.map((item, idx) => `
            <div class="flex justify-between items-center bg-[#111827] p-3 rounded-lg border border-gray-800">
                <span class="text-xs text-white font-bold flex items-center gap-2">
                    <span class="w-5 h-5 rounded bg-yellow-500/10 text-yellow-500 flex items-center justify-center text-[10px]">${idx+1}</span> ${item[0]}
                </span>
                <span class="text-xs text-emerald-400 font-mono font-bold">${item[1].toLocaleString('pt-BR', {style:'currency', currency:'BRL', maximumFractionDigits:0})}</span>
            </div>`).join('');

        try {
            const prompt = `Analise resumo (max 3 linhas): Total R$ ${total.toFixed(2)}, Ticket R$ ${avg.toFixed(2)}. Business insight focado. Markdown.`;
            const aiResponse = await callGemini(prompt, false); 
            elTextReview.innerHTML = marked.parse(aiResponse);
        } catch (e) { elTextReview.innerHTML = "IA Indisponível."; }
    },
    
    openAIDeepDive: () => { app.openModal('modal-ai-deep-dive'); const allData = Object.values(state.data).flat(); app.openAIAnalysis(allData); },

    renderSettings: () => { 
        const drawMachine = (id, list) => document.getElementById(id).innerHTML = list.map((item, idx) => `<li class="flex justify-between items-center bg-gray-900 p-3 rounded-lg border border-gray-700"><span class="text-sm font-bold text-white">${item}</span><div class="flex gap-2"><button onclick="app.editSettingItem('machineTypes', ${idx})" class="text-blue-500"><i class="ph-bold ph-pencil-simple"></i></button><button onclick="app.removeSettingItem('machineTypes', ${idx})" class="text-red-500"><i class="ph-bold ph-trash"></i></button></div></li>`).join(''); 
        const drawServices = (id, list) => document.getElementById(id).innerHTML = list.map((item, idx) => `<li class="flex justify-between items-center bg-gray-900 p-3 rounded-lg border border-gray-700"><div class="flex items-center gap-2"><input type="color" value="${state.serviceColors[item] || '#3b82f6'}" onchange="app.updateServiceColor('${item}', this.value)" class="w-8 h-8 rounded cursor-pointer border-none bg-transparent"><span class="text-sm font-bold text-white">${item}</span></div><div class="flex gap-2"><button onclick="app.editSettingItem('serviceTypes', ${idx})" class="text-blue-500"><i class="ph-bold ph-pencil-simple"></i></button><button onclick="app.removeSettingItem('serviceTypes', ${idx})" class="text-red-500"><i class="ph-bold ph-trash"></i></button></div></li>`).join(''); 
        drawMachine('list-machines', state.machineTypes); drawServices('list-services', state.serviceTypes); 
    },
    addSettingItem: async (type, inputId) => { const val = document.getElementById(inputId).value.trim(); if(val) { state[type].push(val); document.getElementById(inputId).value=""; await setDoc(dbPath, {[type]: state[type]}, {merge:true}); app.renderSettings(); } },
    
    // --- Lógica Modal Customizada (Sem Prompt/Confirm Nativos) ---
    editSettingItem: (type, idx) => {
        const oldName = state[type][idx];
        state.tempPrompt = { type, idx, oldName };
        document.getElementById('modal-prompt-title').textContent = `Renomear "${oldName}"`;
        document.getElementById('modal-prompt-input').value = oldName;
        document.getElementById('modal-prompt').classList.remove('hidden');
    },
    
    executePrompt: async () => {
        const newName = document.getElementById('modal-prompt-input').value.trim();
        const { type, idx, oldName } = state.tempPrompt;
        
        if (newName && newName !== oldName) {
            state[type][idx] = newName;
            
            if (type === 'serviceTypes' && state.serviceColors[oldName]) {
                state.serviceColors[newName] = state.serviceColors[oldName];
                delete state.serviceColors[oldName];
            }

            // Migração de dados históricos
            Object.keys(state.data).forEach(month => {
                if (Array.isArray(state.data[month])) {
                    state.data[month].forEach(entry => {
                        if (type === 'serviceTypes' && entry.servico === oldName) entry.servico = newName;
                        if (type === 'machineTypes' && entry.maquina === oldName) entry.maquina = newName;
                    });
                }
            });

            const updates = { [type]: state[type], fullRawData: state.data };
            if (type === 'serviceTypes') updates.serviceColors = state.serviceColors;

            await setDoc(dbPath, updates, { merge: true });
            app.renderSettings();
            app.updateDashboard();
        }
        document.getElementById('modal-prompt').classList.add('hidden');
    },

    removeSettingItem: (type, idx) => {
        state.tempConfirm = { type: 'setting', settingType: type, idx: idx };
        document.getElementById('modal-confirm').classList.remove('hidden');
    },

    executeConfirm: async () => {
        const target = state.tempConfirm;
        if(!target) return;

        if (target.type === 'setting') {
            state[target.settingType].splice(target.idx, 1);
            await setDoc(dbPath, {[target.settingType]: state[target.settingType]}, {merge:true});
            app.renderSettings();
        } else if (target.type === 'entry') {
            Object.keys(state.data).forEach(m => { 
                if(Array.isArray(state.data[m])) state.data[m] = state.data[m].filter(d => d.id !== target.id); 
            }); 
            await setDoc(dbPath, { fullRawData: state.data }, { merge: true }); 
            app.updateDashboard(); 
            const list = document.getElementById('modal-drill-list'); 
            if(!list.classList.contains('hidden')) app.closeModal('modal-drill-list');
        }
        
        document.getElementById('modal-confirm').classList.add('hidden');
    },

    updateServiceColor: async (service, color) => { 
        state.serviceColors[service] = color; 
        await setDoc(dbPath, { serviceColors: state.serviceColors }, { merge: true }); 
        app.updateDashboard(); 
    },
};

onAuthStateChanged(auth, user => {
    if(user) {
        onSnapshot(dbPath, (snap) => {
            if(snap.exists()) {
                const d = snap.data();
                state.data = d.fullRawData || {};
                state.machineTypes = d.machineTypes || state.machineTypes;
                state.serviceTypes = d.serviceTypes || state.serviceTypes;
                state.serviceColors = d.serviceColors || state.serviceColors; 
                document.getElementById('db-status-dot').className = "w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-glow";
                app.updateDashboard();
            }
        });
    } else { signInAnonymously(auth); }
});

const today = new Date().toISOString().substring(0, 7);
document.getElementById('date-start').value = today;
document.getElementById('date-end').value = today;
document.getElementById('date-single').value = today;